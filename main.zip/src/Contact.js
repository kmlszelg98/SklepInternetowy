import React, { Component } from "react";
 
class Contact extends React.Component {
  render() {
    return (
      <div class="container">
		<hr class="divider"></hr>
		<div class="row">
			<div class="col-lg-8">
            <div class="embed-responsive embed-responsive-16by9 map-container mb-4 mb-lg-0">
              <iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?hl=en&amp;ie=UTF8&amp;ll=37.0625,-95.677068&amp;spn=20.506174,150.013672&amp;t=m&amp;z=4&amp;output=embed"></iframe>
            </div>
			</div>
			
			<div class="col-lg-4">
			<h5 class="mb-0">Phone:</h5>
			<div class="mb-4">696 724 607</div>
			<h5 class="mb-0">Email:</h5>
			<div class="mb-4">
              <a href="mailto:name@example.com">kmlszelg98@gmail.com</a>
            </div>
			<h5 class="mb-0">Address:</h5>
			<div class="mb-4">

              42 Crown Street

              <br></br>

              London

            </div>
			</div>
		</div>
      </div>
    );
  }
}
 
export default Contact