import React, { Component } from "react";
import PaypalExpressBtn from 'react-paypal-express-checkout';


 
class Card extends React.Component {
	
	constructor() {
		super();
		this.state ={sum:0, list: [],txt:"First",elem:[],elemAr:[],result:true, mw:"witam"};
		if(window.sessionStorage.getItem("key3")!=null){
			this.state.list = JSON.parse(window.sessionStorage.getItem("key3"));
		}
		this.state.list.map(function(item){			
			this.load(item);			
		},this);
		
	}
	
	componentDidMount(){
		const s = document.createElement('script');
		s.type = 'text/javascript';
		s.async = true;
		s.src = "./script.js";
		document.body.appendChild(s);
	}
	
	remove(id){
		this.state.list.splice(id,1);
		window.sessionStorage.setItem("key3",JSON.stringify(this.state.list));
		this.forceUpdate();
	}
	
	onButtonClick(which) {
		console.log("Start");
	}
	
	next(){		
		this.setState({ txt: 'Clicked'});
	}
	
	back(){		
		this.setState({ txt: 'First'});
		//window.location.reload();
	}
	
	load(which){
		return fetch('/tea/product/'+which.key1.id)
			.then((response) => response.json())
			.then (( responseJson) => {
				this.setState({
					elem: responseJson.data
				});
				console.log(this.state.elem.length);
				console.log(this.state.elem[0].count);
				this.check(which);
			})		
	}
	
	check(obj){
		var f1 = obj.value1;
		var f2 = this.state.elem[0].count;
		
		if(f2<f1) this.setState({result:false});
		console.log(this.state.result);
		this.state.elemAr.push(f2-f1);
		console.log(f2-f1);
	}
	
	update(which, howMany){
		console.log('How');
		console.log(howMany);
		var dict = {};
		dict.count=howMany;
		return fetch('/tea/update/'+which,	
		{
			method: "POST",
			body: JSON.stringify(dict),
			headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
			}
		}		
		
		);
	}
	
	trySend(){
		
		if(this.state.result==false) {
			window.alert("I am sorry products has been sold");
			window.sessionStorage.setItem("result","I AM SORRY");
			this.props.history.push("/result")
		} else {
			this.state.list.map(function(item){
				var w = this.state.elemAr[this.state.list.indexOf(item)];
				console.log(w);
				this.update(item.key1.id, w);
			},this)
			this.setState({list:[]});
			window.sessionStorage.setItem("key3",JSON.stringify([]));
			window.alert("Congratulations, we have your order");
			window.sessionStorage.setItem("result","SUCCESS");
			this.props.history.push("/result")
		}
		this.setState({ txt: 'First'});
	}
	
	
  render() {
	var count = 0;
	var test2 = "First";
	var test3= "Clicked";
	
	
	
	const test = this.state.list.map(function(item) {
		var pr = item.value1*item.key1.price;
		count = count + pr;
		return <tr>
			<td>{item.key1.name}</td>
			<td>{item.key1.price}</td>
			<td>{item.value1}</td>
			<td>{pr}</td>
			<td><button onClick={() => this.remove(this.state.list.indexOf(item))} class="btn btn-secondary">Remove</button></td>
		</tr>
	},this)
	
	    

	return (
      <div>	
		<script src="https://www.paypalobjects.com/api/paypal.checkout.v4.js"></script>
		

		{this.state.txt==test2 &&
		<div>
		<table class="table">
		<thead class="thead-inverse">
		<tr class="table-active">
			<th>Name</th>
			<th>Price</th>
			<th>Count</th>
			<th>Sum</th>
			<th>Action</th>
		</tr>
		</thead>
		<tbody>
		{test}
		</tbody>
		<tfoot>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td>{count}</td>
			<td><button onClick={() => this.next()} class="btn btn-secondary">Pay for it</button></td>
		</tr>
		</tfoot>
		</table>
		</div>
		}
		
		{this.state.txt==test3 &&
		<div>
			<button onClick={() => this.back()}	 class="btn btn-secondary"><span class="glyphicon glyphicon-arrow-left"></span></button>
			<form action="/action_page.php">
				<div class="form-group">
					<label for="name">Name and Surname:</label>
					<input type="text" class="form-control" id="name"></input>
				</div>
				<div class="form-group">
					<label for="adres">Adress:</label>
					<input type="text" class="form-control" id="adres"></input>
				</div>
				<div class="form-group">
					<label for="kod">Postal Code</label>
					<input type="text" class="form-control" id="kod"></input>
				</div>
				<div class="form-group">
					<label for="tel">Phone number</label>
					<input type="text" class="form-control" id="tel"></input>
				</div>
				
			<button onClick={() => this.trySend()} class="btn btn-default">Wyślij zgłoszenie</button>
			</form> 
		</div>
		}
      </div>
    );
  }
}
 
export default Card