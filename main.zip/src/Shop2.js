import React, { Component } from "react";
 
function start(txt){
	var str1 = "First"
	if(str1==txt) {
		return null
	}
	else {
		return <div><h2>Test</h2></div> 
	}
}

class Shop2 extends React.Component {
	

	constructor(){
		super();
		this.state={text: 'First'};
		this.state = { list: [] }
	}
	
	onButtonClick() {
		this.setState({ text: 'Next' });
	}
	
	componentDidMount(){
		return fetch('/Black')
		.then((response) => response.json())
		.then (( responseJson) => {
			console.log( responseJson)
			this.setState({
				list: responseJson.data
			});
		})
	}
	
  render() {
	var test = "First"
    return (
      <div>
		{this.state.text==test &&
		<button onClick={this.onButtonClick.bind(this)}>Button</button>
		}
		{start(this.state.text)}        
      </div>
    );
	
  }
}
 
export default Shop2