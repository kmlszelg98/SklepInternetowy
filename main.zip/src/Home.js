import React, { Component } from "react";
 
class Home extends React.Component {
  render() {
    return (
      <div>
		
		<div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/teatime.jpg" alt=""></img> 
		  <div class="card-img-overlay">
            <h2 class="card-title text-shadow text-gray text-uppercase mb-0">Welcome in Tea House</h2>
          </div>
        </div>		
		
		
		</div>
 
      </div>
    );
  }
}
 
export default Home