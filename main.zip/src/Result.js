import React, { Component } from "react";
 
class Result extends React.Component {
	
	constructor(){
		super();
	}
	
  render() {
    return (
      <div>
		<div class="bg-faded p-4 my-4">        
          <h1>{window.sessionStorage.getItem("result")}</h1>
        </div>	
		
      </div>
    );
  }
}
 
export default Result