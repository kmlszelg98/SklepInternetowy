import React, { Component } from "react";
import { HashRouter as Router, Route, NavLink } from 'react-router-dom';
import './index.css'

function start(txt){
	var str1 = "First"
	if(str1==txt) {
		return null
	}
	else {
		return 
		
	}
}

class Shop extends React.Component {
	
	constructor() {
		super();
		this.state ={txt: 'First', list: []};
		//window.sessionStorage.setItem("key3", JSON.stringify([]));
		//window.localStorage.setItem("key3",JSON.stringify([]));
		if(window.sessionStorage.getItem("key3")==null){
			window.sessionStorage.setItem("key3",JSON.stringify([]));
		}		
	}
	
	lookForDuplicate(obj, newObj){
		
		var res = false;
		obj.map(function(item){
			
			if(item.key1.id==newObj.key1.id){	
				item.value1 = newObj.value1;
				res = true;
			}
		});
		if(res == false){
		obj.push(newObj);
		}
	}
	
	
	addToCart(id, field){
		var obj = JSON.parse(window.sessionStorage.getItem("key3"))
		var dict = {};
		var key =  {};
		key.id = this.state.list[id].id;
		key.name = this.state.list[id].name;
		key.price = this.state.list[id].price;
		dict.key1 = key;
		var obj2 = document.getElementById(field);
		dict.value1 = parseInt(obj2.value.substring(0) , 10 );
		console.log(dict);
		this.lookForDuplicate(obj, dict);
		window.sessionStorage.setItem("key3",JSON.stringify(obj));
	}
	
	back(){		
		this.setState({ txt: 'First'});
	}
	
	add(which, count){
		var obj = document.getElementById(which);
		var v = parseInt(obj.value.substring(0) , 10 );
		if(v < count){
			obj.value =  v + 1;
		}
		
	}
	
	del(which){
		var obj = document.getElementById(which);
		var v = parseInt(obj.value.substring(0) , 10 );
		if(v > 1){
			obj.value =  v - 1;
		}
	}
	
	
	onButtonClick(which) {
		this.load(which);
		this.setState({ txt: 'Clicked!'});
	}
	
	load(which){
		if(which=='0')
		{
			return fetch('/tea/0')
			.then((response) => response.json())
			.then (( responseJson) => {
				console.log( responseJson)
				this.setState({
					list: responseJson.data
				});
			})
		} else if ( which=='1')
		{
			return fetch('/tea/1')
			.then((response) => response.json())
			.then (( responseJson) => {
				console.log( responseJson)
				this.setState({
					list: responseJson.data
				});
			})
		} 
		else if ( which=='2')
		{
			return fetch('/tea/2')
			.then((response) => response.json())
			.then (( responseJson) => {
				console.log( responseJson)
				this.setState({
					list: responseJson.data
				});
			})
		} 
		else
		{
			return fetch('/tea/3')
			.then((response) => response.json())
			.then (( responseJson) => {
				console.log( responseJson)
				this.setState({
					list: responseJson.data
				});
			})
		} 
	}
	


  render() {
	
	var test = "First";
	var test2= "Clicked!";
    return (
      <div>
		<h2>{this.state.tt}</h2>
		{this.state.txt==test &&
		<div class="row">
		<div class="col-lg-6">
		<div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/black-tea.jpg" alt=""></img>
          <div class="card-img-overlay bg-overlay">
            <h2 class="card-title text-shadow text-white text-uppercase mb-0">Black Tea</h2>
            <h4 class="text-shadow text-white"></h4>
            <button onClick={() => this.onButtonClick(0)}	 class="btn btn-secondary">Taste it</button>
          </div>
        </div>		
		</div>
		</div>
		
		<div class="col-lg-6">
		<div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/green-tea.jpg" alt=""></img>
          <div class="card-img-overlay bg-overlay">
            <h2 class="card-title text-shadow text-white text-uppercase mb-0">Green Tea</h2>
            <h4 class="text-shadow text-white"></h4>
            <button onClick={() => this.onButtonClick(1)}	 class="btn btn-secondary">Taste it</button>
          </div>
        </div>		
		</div>
		</div>
		</div>
		}
		
		{this.state.txt==test &&
		<div class="row">
		<div class="col-lg-6">
		<div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/herbal-tea.jpg" alt=""></img>
          <div class="card-img-overlay bg-overlay">
            <h2 class="card-title text-shadow text-white text-uppercase mb-0">Herbal Tea</h2>
            <h4 class="text-shadow text-white"></h4>
            <button onClick={() => this.onButtonClick(2)} class="btn btn-secondary">Taste it</button>
          </div>
        </div>		
		</div>
		</div>
		
		<div class="col-lg-6">
		<div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/fruit-tea.jpg" alt=""></img>
          <div class="card-img-overlay bg-overlay">
            <h2 class="card-title text-shadow text-white text-uppercase mb-0">Fruit Tea</h2>
            <h4 class="text-shadow text-white"></h4>
            <button onClick={() => this.onButtonClick(3)} class="btn btn-secondary">Taste it</button>
          </div>
        </div>		
		</div>
		</div>
		
		
		</div>
		}
		
		{this.state.txt==test2 &&
		<div>      
         
			
			<button onClick={() => this.back()}	 class="btn btn-secondary"><span class="glyphicon glyphicon-arrow-left">&nbsp;Back&ensp;to&ensp;previous&ensp;page</span></button>
			{this.state.list.map(function(name){
				var str = name.name.replace(/ /g, '');
				return 	<div class="col-lg-12">
						<hr className="Line"></hr>
						<div class="col-lg-4">
						<div class="bg-faded p-4 my-4">
							<div class="card card-inverse">
							<img class="card-img img-fluid w-100" src={"img/"+name.type+"/"+str+".png"} alt=""></img>
							<div class="card-img-overlay bg-overlay">
							
							</div>
							</div>
						</div>
						</div>
						<div class="col-lg-8">
							<h1 className="Name">{name.name}</h1>						
							<h3>{name.description}</h3>
							<h3>Price: {name.price}</h3>
							<form >
							<div class="col-lg-4">
							<div class="input-group">
								<span class="input-group-btn">
								<button onClick={() => this.del("ref"+name.id)} class="btn btn-secondary" type="button" id="btn-minus"><span class="glyphicon glyphicon-minus"></span></button>
								</span>
								<input type="text" class="form-control" name="qty" ref={"ref"+name.id} id={"ref"+name.id} value="1" />
								<span class="input-group-btn">
								<button onClick={() => this.add("ref"+name.id, name.count)} class="btn btn-secondary" type="button" id="btn-plus"><span class="glyphicon glyphicon-plus"></span></button>
								</span>
							</div>
							
							</div>
							
							<h3>out of {name.count}</h3>
							<br></br>
							<button onClick={() => this.addToCart(this.state.list.indexOf(name),"ref"+name.id)} class="btn btn-secondary" type="button" >Add to card</button>
							
							<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
								<input type="hidden" name="cmd" value="_xclick"></input>
								<input type="hidden" name="business" value="kmlszelg65@gmail.com"></input>
								<input type="hidden" name="lc" value="US"></input>
								<input type="hidden" name="item_name" value="Product2"></input>
								<input type="hidden" name="item_number" value="12345"></input>
								<input type="hidden" name="amount" value={name.price}></input>
								<input type="hidden" name="currency_code" value="GBP"></input>
								<input type="hidden" name="button_subtype" value="services"></input>
								<input type="hidden" name="no_note" value="0"></input>
								<input type="hidden" name="cbt" value="https://google.com"></input>
								<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynowCC_LG.gif:NonHostedGuest"></input>
								<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"></input>
								<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1"></img>
							</form>
							
						

							
							</form>
							
							
						</div>
						
						<hr className="Line"></hr>
						</div>
	
			}, this)}
			
					

		</div>
		}
		
		    
      </div>
    );
  }
}
 
export default Shop