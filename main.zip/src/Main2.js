import React, { Component } from "react";
import { HashRouter as Router, Route, NavLink } from 'react-router-dom';

import Home from "./Home";
import Shop from "./Shop";
import Contact from "./Contact";
import Card from "./Card";
import './index.css'




const style2 = {
	paddingLeft: '35%'
}

const style3 = {
	width: '50%'
}
 
class Main2 extends Component {
	
	constructor(props){
		super(props)
		this.state = { message:""}
		this.state = { list: [] }
	}
	
	
		
	add(){
		
	}
	
	wynik(){
		
	}
	
	componentDidMount(){
		const script = document.createElement("script");
		script.src = "https://www.paypalobjects.com/api/checkout.js";
		document.body.appendChild(script);
		
		const script2 = document.createElement("script");
		script2.src = "./script.js";
		document.body.appendChild(script2);
	}
	
	
  render() {
	var names = ['Jake', 'Jon', 'Thruster'];

    return (
		<Router>
		<div>
			<div className="tagline-upper text-center text-heading text-shadow text-white mt-5 d-none d-lg-block">Tea House</div>
			<div className="tagline-lower text-center text-expanded text-shadow text-uppercase text-white mb-5 d-none d-lg-block">42 Crown Street | London </div>

			<div className="container">
			<nav className="navbar navbar-expand-lg navbar-light bg-faded py-lg-4">
			
				
			
			</nav>
			</div>
			
			
			<div className="container">
				<div className="bg-faded p-4 my-4">
					
					<div id="paypal-button-container"></div>
					<button onClick={() => this.add()} class="btn btn-secondary" type="button" id="btn-plus">Next</button>
					<button onClick={() => this.wynik()} class="btn btn-secondary" type="button" id="btn-plus">Next2</button>
					
				</div>
			</div>
			
			<div>
             	
          	</div> 
		

    

		</div>
		</Router>


    );
  }
}
 
export default Main2;