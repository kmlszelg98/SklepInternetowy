import React, { Component } from "react";
import { HashRouter as Router, Route, NavLink } from 'react-router-dom';

import Home from "./Home";
import Shop from "./Shop";
import Contact from "./Contact";
import Card from "./Card";
import Result from "./Result"
import './index.css'


const style2 = {
	paddingLeft: '35%'
}
 
class Main extends Component {
	
	constructor(props){
		super(props)
		this.state = { message:""}
		this.state = { list: [] }
	}
	
	
	
	
	
  render() {
	var names = ['Jake', 'Jon', 'Thruster'];

    return (
		<Router>
		<div>
			<div className="tagline-upper text-center text-heading text-shadow text-white mt-5 d-none d-lg-block">Tea House</div>
			<div className="tagline-lower text-center text-expanded text-shadow text-uppercase text-white mb-5 d-none d-lg-block">42 Crown Street | London </div>

			<div className="container">
			<nav className="navbar navbar-expand-lg navbar-light bg-faded py-lg-4">
			
				<a className="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="#">Start Bootstrap</a>
				<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
					<span className="navbar-toggler-icon"></span>
				</button>
				<div className="collapse navbar-collapse" id="navbarResponsive">
				<ul className="navbar-nav mx-auto" style = {style2} >
					<li className="nav-item active px-lg-4" >
						<a className="nav-link text-uppercase text-expanded" >
							<NavLink exact={true} to="/" className="Button" style={{ textDecoration: 'none' }}>Home</NavLink>
						</a>
					</li>
					<li className="nav-item px-lg-4" >
						<a className="nav-link text-uppercase text-expanded">
							<li className="nav-item px-lg-4" ><NavLink to="/shop" className="Button" style={{ textDecoration: 'none' }}>Shop</NavLink></li>
						</a>
					</li>
					<li className="nav-item px-lg-4" >
						<a className="nav-link text-uppercase text-expanded">
							<NavLink to="/contact" className="Button" style={{ textDecoration: 'none' }}>Contact</NavLink>
						</a>
					</li>
					<li className="nav-item px-lg-4" >
						<a className="nav-link text-uppercase text-expanded">
							<NavLink to="/card" className="Button" style={{ textDecoration: 'none' }}>Card</NavLink>
						</a>
					</li>
					
				</ul>
				</div>
			
			</nav>
			</div>
			
			<div className="container">
				<div className="bg-faded p-4 my-4">
					<Route exact path="/" component={Home}/>
            		<Route path="/shop" component={Shop}/>
            		<Route path="/contact" component={Contact}/>
					<Route path="/card" component={Card}/>
					<Route path="/result" component={Result}/>
				</div>
			</div>
			
			<div>
             	
          	</div> 
		

    

		</div>
		</Router>


    );
  }
}
 
export default Main;