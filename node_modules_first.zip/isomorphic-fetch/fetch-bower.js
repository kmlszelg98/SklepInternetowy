module.exports = require('fetch');
