1.0.1 / 2015-09-27
=================
  * [Fix] If `@@toStringTag` is not present, use the old-school `Object#toString` test
  * [Docs] Switch from vb.teelaun.ch to versionbadg.es for the npm version badge SVG
  * [Dev Deps] update `is`, `eslint`, `@ljharb/eslint-config`, `semver`, `tape`, `jscs`, `nsp`, `covert`
  * [Tests] up to `io.js` `v3.3`, `node` `v4.1`

1.0.0 / 2015-01-28
=================
  * Initial release.
