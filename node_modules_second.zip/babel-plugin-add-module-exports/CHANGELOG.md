
0.2.1
---
 - [2016-05-12 16:20:17 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/77cc52a366e237e22bae8a84abab1d7b13cb1078) perf: use babel/scripts/add-module-exports as reference implementation([#34](https://github.com/59naga/babel-plugin-add-module-exports/issues/34)) by 59naga

0.2.0
---
 - [2016-05-05 01:40:16 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/a07c2747e59b04cd0b0a4862f903e617b5a7612e) perf: use `template` argument property instead of `babel-template` by 59naga
 - [2016-04-27 08:01:52 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/d1922e66cef0f1ad16b4e00829e7b379015af747) Add node-v6 in TravisCI :tada: by 59naga
 - [2016-04-27 04:59:25 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/fe69568dbbd03d7ac93d52eb8b495d2a5a624417) docs(CHANGELOG): change date format to ISO 8601 [skip ci] by 59naga

0.1.4
---
 - [2016-04-27 02:11:44 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/8c39825bd2e360463179a428951fd1061d7f106a) Merge pull request [#33](https://github.com/59naga/babel-plugin-add-module-exports/issues/33) from 59naga/patch-1 by 59naga
 - [2016-04-27 01:35:24 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/ae8b254037dc3b839cf110711afe6c3c189c211e) chore: tweaks version/postversion by 59naga
 - [2016-04-27 01:12:25 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/8471534665bf90e2bdb43cb028912cbd5383c5f7) Fix [#31](https://github.com/59naga/babel-plugin-add-module-exports/issues/31) by 59naga
 - [2016-04-27 00:48:48 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/83d975c4581b35816e303c6c5de4221147b43543) Remove unnecessary `lodash.get` by 59naga
 - [2016-04-26 04:18:39 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/50253c83cd117ebe1218d2e94e9e69729cf8fde1) Tweaks changelog.js/CHANGELOG.md [skip ci] by 59naga

0.1.3
---
 - [2016-04-26 04:10:55 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/29b883ae0f99ef5ce9b58220900103c1edc1d5d0) Add changelog.js for CHANGELOG.md [skip ci] by 59naga
 - [2016-04-26 02:34:43 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/0303039c4d429245db2d6e9eacc2d4a9a8d365fa) Fix [#30](https://github.com/59naga/babel-plugin-add-module-exports/issues/30) by 59naga
 - [2016-04-24 12:08:41 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/af192976a03242833a811167931a2f8a0c12dcff) Add .npmignore for `npm publish` by 59naga
 - [2016-04-24 11:17:05 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/3d140241f6bd91e5725525c5e37b4c6bd3fbed50) Merge pull request [#29](https://github.com/59naga/babel-plugin-add-module-exports/issues/29) from 59naga/5to6 by 59naga
 - [2016-04-24 10:55:47 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/7ee202221a6d2b17dd2733baf160f5ca2fbaa5a1) Add `npm start` script by 59naga
 - [2016-04-24 09:35:21 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/0d594fa90fabd3c95c2598d4fb574f00cfd4195c) Change 5 to 6 syntax by 59naga
 - [2016-04-24 08:18:24 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/dbe1107fc7b35e268eab836c5fdab98a870336b7) Add node@0 in TravisCI by 59naga
 - [2016-04-24 08:17:24 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/7fa8dcc3078d7cc6acfafc7bdc2860f9af2c361c) Rename lib/index.js -> src/index.js by 59naga
 - [2016-04-24 08:15:12 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/b684ec0269fa532ee7c4ae117307d9ab682f01d5) Update the devDependencies by 59naga
 - [2016-02-10 00:50:54 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/9e697076ed72836bde21419b24da072c5fd1a622) Update deps and devDeps(refs [#25](https://github.com/59naga/babel-plugin-add-module-exports/issues/25),[#24](https://github.com/59naga/babel-plugin-add-module-exports/issues/24)) by 59naga
 - [2016-01-23 08:12:31 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/c7665bcfca8de39cdcc26bdec93ee9f6f757ef28) Merge pull request [#23](https://github.com/59naga/babel-plugin-add-module-exports/issues/23) from lijunle/readme-usage by 59naga
 - [2016-01-22 22:44:40 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/6cd4a8f0d0792b6f834a00f11efc579c50a57f2f) Add the usage section in README. by Junle Li
 - [2016-01-22 01:31:00 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/0cbd7e6c68f28cbc34c1a5f9d530028105138a28) Revert "0.1.3-alpha Follow the [#20](https://github.com/59naga/babel-plugin-add-module-exports/issues/20)" by 59naga
 - [2016-01-16 17:00:22 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/588789cc856c39e3ef29a558cf8d18e553350fe6) Update the README, keep it clean. by Junle Li

0.1.2
---
 - [2015-11-23 21:05:02 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/db851a76609297a59e387665d6fe60781db0c671) Remove no longer used `engines` (Fix [#15](https://github.com/59naga/babel-plugin-add-module-exports/issues/15)) by 59naga
 - [2015-11-20 03:01:58 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/7887776e9e45aa6cf6143a056ac7ffe2aa83e7d1) :pencil2: Move link github-issues to phabricator (Fix [#14](https://github.com/59naga/babel-plugin-add-module-exports/issues/14)) by 59naga
 - [2015-11-19 23:53:35 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/5be793589d6f7c62e2d0f992001eebbe32e82ad4) Merge pull request [#13](https://github.com/59naga/babel-plugin-add-module-exports/issues/13) from lijunle/travis-matrix by 59naga
 - [2015-11-14 19:28:25 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/8d4efffbd13fec69c2a46e3627465bbe8ef8d22b) Enable Travis CI build matrix. by Junle Li

0.1.1
---
 - [2015-11-15 18:20:28 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/e1bbbf03b31d0d2036d3daed4b60d642a90aae21) Fix [#11](https://github.com/59naga/babel-plugin-add-module-exports/issues/11) by 59naga
 - [2015-11-15 17:51:01 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/9b8b496ee972f1ee15bb638f9bbc99403d7452b6) Add spec `should export using transform-export-extensions (#11)` by 59naga

0.1.0
---
 - [2015-11-15 16:37:30 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/d4d127891244ea24023f070d58c66d41845ea7a3) Fix eslint eol-last rule by 59naga
 - [2015-11-15 16:35:25 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/36581888f9c60bd7bb0a2fe694f8d741d6caded5) Fix [#4](https://github.com/59naga/babel-plugin-add-module-exports/issues/4) by 59naga
 - [2015-11-15 16:30:02 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/9ef0a386bd4cb33e487361b183e80a0f4104b628) Adjust the overview to breaking changes. by 59naga
 - [2015-11-15 16:27:17 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/88ddf7bab0630cde10acfbe06aaa664679577eb4) Breaking change to follow the babel@5 behavior by 59naga
 - [2015-11-15 16:25:52 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/679011d2a53f46ffa483013e522e70cd7f30d96d) Merge pull request [#9](https://github.com/59naga/babel-plugin-add-module-exports/issues/9) from lijunle/babel-5-behavior by 59naga
 - [2015-11-15 16:24:07 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/79ad4bfda1d831515afd0ac05a69c1024989d50f) Revert "Enable Travis CI build matrix. feat @lijunle" by 59naga
 - [2015-11-14 19:11:22 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/f27bfe986eb9aaa8adb9e32b117ec71bb4c328f2) Revisit the legacy test cases. by Junle Li
 - [2015-11-14 19:00:47 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/ebf24548fb7e51658c7f1352c918acbcae5fdfc9) Follow the Babel@5 bahavior. by Junle Li
 - [2015-11-14 18:42:07 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/eeb8236cb2362de9e4be79b76f69d7f13bc31d76) Refine testPlugin helper work with test spec. by Junle Li
 - [2015-11-14 18:37:47 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/fc69edcdc38afe87f35509dae286e63f6e59573f) Add the test specs. by Junle Li
 - [2015-11-14 15:50:35 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/e27cbb99629d2989a130b961e3d95c7a3d34f270) Merge pull request [#8](https://github.com/59naga/babel-plugin-add-module-exports/issues/8) from lijunle/test-refinement by 59naga
 - [2015-11-14 04:57:15 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/103141efc399d885ddb523ea35a31c734ef3d126) Give a more meaningful test name. by Junle Li
 - [2015-11-14 04:53:02 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/cbe903b027f5e6df7767e0dc858ee3db61866879) Refine the test case to be stable. by Junle Li
 - [2015-11-14 04:45:26 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/c9f8384c8ff99686706b07f7d1c9f1dc4056ad88) Increase the timeout to 30 second. by Junle Li
 - [2015-11-14 04:41:42 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/f75e072c0a526d86ab3a23642160a005dbd5b3b5) Remove transform-es2015-modules-commonjs plugin. by Junle Li
 - [2015-11-14 07:53:24 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/2e0dd6bbd67f7734692a10c9eb280e77b729b70c) Merge pull request [#6](https://github.com/59naga/babel-plugin-add-module-exports/issues/6) from lijunle/develop-refinement by 59naga
 - [2015-11-14 00:17:58 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/7ba871070e3e30fd16e5ff1e065b1273c46c6478) Add git ignore file. by Junle Li
 - [2015-11-14 04:30:03 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/f3c67e8a29f74e5df4032e5ef2ff225a120d2f8f) Remove git hooks. by Junle Li
 - [2015-11-14 04:26:42 +0800](https://github.com/59naga/babel-plugin-add-module-exports/commit/15352dc298ce34d606e95c2733795692226b6805) Resolve standard code style warnings. by Junle Li
 - [2015-11-14 01:27:47 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/f814859b37cdbcbafb6fb31f4a54b2317f4b1eec) Fix [#5](https://github.com/59naga/babel-plugin-add-module-exports/issues/5) by 59naga
 - [2015-11-13 21:19:53 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/d5d5bce92115d58cf698ab49813f0b92ae4751ca) Code refactor (ref [#4](https://github.com/59naga/babel-plugin-add-module-exports/issues/4)) by 59naga
 - [2015-11-13 08:26:42 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/d41fb2e94b95c4c9c20dca87486a4eee7f4a4775) Change regexp to AST properties (ref [#4](https://github.com/59naga/babel-plugin-add-module-exports/issues/4)) by 59naga
 - [2015-11-12 07:55:36 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/2bd5a811e07beaf967d0b051a4684ee4a48738e8) :memo: transform-es2015-modules-commonjs@6.1.4 [skip ci] by 59naga
 - [2015-11-12 01:30:01 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/60d57567fa2d69fd49a3dbffcf7e3fed2c4f32cd) :pencil2: typo [skip ci] by 59naga

0.0.4
---
 - [2015-11-11 17:57:44 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/00042ccada436086b59187608ac953e1a8d53492) 0.0.4 Fix [#2](https://github.com/59naga/babel-plugin-add-module-exports/issues/2) by 59naga
 - [2015-11-11 10:48:34 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/ed2854488287ffa7250d4e997dbdc7dd11575599) :pencil2: [ci skip] by 59naga
 - [2015-11-11 10:37:24 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/4376e9ca9e6446501923c30cf8111ba9b4cbebe9) :pencil2: [ci skip] by 59naga

0.0.3
---
 - [2015-11-11 08:54:39 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/465b516593e88f3e9746c51a4d518dc5812c067f) 0.0.3 Move babel-template devDeps -> deps by 59naga

0.0.2
---
 - [2015-11-11 08:11:47 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/8806baef030a51464caceab9444f2a638eb09300) 0.0.2 Fix [#2](https://github.com/59naga/babel-plugin-add-module-exports/issues/2) by 59naga

0.0.1
---
 - [2015-11-11 07:16:49 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/6d98943921707c3cf62f7ff0a7466694f082bd5e) 0.0.1 Use Object.assign by 59naga
 - [2015-11-11 06:53:52 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/4543bb8f95bae80af3aefc4ac798d8d97dca0624) :pencil2: Blurred subject [skip ci] by 59naga
 - [2015-11-11 06:36:12 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/2ff94f50a1c0e28589dc6525dcd636bed5f74d98) Fix `Error: timeout of 2000ms exceeded` by 59naga
 - [2015-11-11 05:37:32 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/c47bb93e1ef2cfa111003eaf3e7405a683fa0b06) Fix 6 to 5 by 59naga
 - [2015-11-11 05:33:50 +0900](https://github.com/59naga/babel-plugin-add-module-exports/commit/9e0628799e766a5eedaadb774cef3d8adb84426b) Initial by 59naga
