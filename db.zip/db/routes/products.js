
exports.List = function(req,res){
	
	console.log("TEST");
	req.getConnection(function(err,connection){
		var query = connection.query('SELECT * FROM tea',function(err,rows)
		{
			if(err) console.log("Error Selecting : %s ",err );
			
			res.json({data:rows});
			
		});
	});
}

exports.ListType = function(req,res){
          
     var id = req.params.id;
    
     req.getConnection(function (err, connection) {
        
        connection.query("SELECT * FROM tea WHERE type = ? ",[id], function(err, rows)
        {
            
             if(err)
                 console.log("Error deleting : %s ",err );
            
             res.json({data:rows});
             
        });
        
     });
};

exports.Update = function(req,res){
    
	var input = JSON.parse(JSON.stringify(req.body));
    var id = req.params.id;
	
	
	req.getConnection(function (err, connection) {
        
        var query = connection.query("UPDATE tea set count= ? WHERE id= ? ",[input.count,id], function(err, rows)
        {
  
          if (err)
              console.log("Error Updating : %s ",err );
				res.json({data:rows});
          
        });
    
    });
};

exports.Typelist = function(req,res){
	var id = req.params.id;
	
	req.getConnection(function(err,connection){
		var query = connection.query("SELECT * FROM tea WHERE type = ? ",[id],function(err,rows)
		{
			if(err) console.log("Error Selecting : %s ",err );
			
			res.json({data:rows});
			
		});
	});
}

exports.Elements = function(req,res){
	var id = req.params.id;
	
	req.getConnection(function(err,connection){
		var query = connection.query("SELECT * FROM tea WHERE id = ? ",[id],function(err,rows)
		{
			if(err) console.log("Error Selecting : %s ",err );
			
			res.json({data:rows});
			
		});
	});
}

